import os

from celery import Celery

# устанавливает переменную окружения DJANGO_SETTINGS_MODULE в значение config.settings. Это говорит Celery, где находятся настройки Django.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

# создает экземпляр Celery приложения с именем config
app = Celery('config')

# загружает настройки Celery из объекта django.conf.settings и устанавливает их в пространстве имен CELERY
app.config_from_object('django.conf:settings', namespace='CELERY')
# автоматически находит и регистрирует задачи (tasks) в приложении
app.autodiscover_tasks()
