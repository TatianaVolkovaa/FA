from django.contrib import admin
from analytics.models import Group


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('link', 'name', 'count_members', 'er', 'tr', 'lr', 'status')
    list_filter = ('status',)
    search_fields = ('link', 'name')
