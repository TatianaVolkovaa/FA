import re
from threading import Thread

import backoff
import requests

import string
from pymystem3 import Mystem

BASE_URL = 'https://api.vk.com/method/'
API_VERSION = 'v=5.131'
HEADERS = {'Authorization': 'Bearer 781b939e781b939e781b939ed47b08d25b7781b781b939e1c3ac44c423272b4f874bc02'}
CURRENT_YEAR = 2023


def get_common_info(group_name):
    params = {
        'group_id': group_name,
        'v': '5.131',
        'fields': 'activity, city, description, members_count, start_date, status'
    }
    response = requests.get(f'{BASE_URL}groups.getById', params=params, headers=HEADERS)

    if response.status_code == 200:
        body = response.json()
        if 'response' in body:
            body = body['response'][0]
            count = body.get('members_count')
            name = body.get('name')

            return {'count_members': count, 'name': name}

    return None


def get_members_info(group_name, group_info):
    params = {
        'group_id': group_name,
        'v': '5.131',
        'fields': 'sex, country, city, bdate',
        'count': 1000
    }
    members_info = {'female': 0, 'male': 0}

    total_batches = int(int(group_info['count_members']) / 1000) + 1

    threads = [None] * total_batches
    results = [None] * total_batches

    for i in range(0, total_batches):
        threads[i] = Thread(target=open_url, args=(params, f'{BASE_URL}groups.getMembers', results, i, i * params['count']))

    thread_processing(threads, total_batches, 10)
    members_info.update({
        'city': {},
        'country': {},
        'age': {'до 18': 0, '18-24': 0, '25-34': 0, '35-44': 0, '45-54': 0, 'более 55': 0}
    })

    for response in results:
        try:
            if response.status_code == 200:
                body = response.json()
                if 'response' in body:
                    members = body['response']['items']

                    for member in members:

                        if 'sex' in member:
                            if member['sex'] == 2:
                                members_info['male'] += 1
                            elif member['sex'] == 1:
                                members_info['female'] += 1

                        if 'country' in member:
                            if 'title' in member['country']:
                                title = member['country']['title']
                                if title in members_info['country']:
                                    members_info['country'][title] += 1
                                else:
                                    members_info['country'][title] = 1

                        if 'city' in member:
                            if 'title' in member['city']:
                                title = member['city']['title']
                                if title in members_info['city']:
                                    members_info['city'][title] += 1
                                else:
                                    members_info['city'][title] = 1

                        if 'bdate' in member:
                            bdate = member['bdate'].split('.')
                            if len(bdate) == 3:
                                year = int(bdate[2])
                                age = CURRENT_YEAR - year
                                if age < 18:
                                    members_info['age']['до 18'] += 1
                                elif 18 <= age < 25:
                                    members_info['age']['18-24'] += 1
                                elif 25 <= age < 35:
                                    members_info['age']['25-34'] += 1
                                elif 35 <= age < 45:
                                    members_info['age']['35-44'] += 1
                                elif 45 <= age < 55:
                                    members_info['age']['45-54'] += 1
                                else:
                                    members_info['age']['более 55'] += 1

        except:
            pass

    group_info['members_info'] = members_info
    print(members_info)
    return group_info


def get_wall_info(group_name, group_info):
    params = {
        'domain': group_name,
        'v': '5.131'
    }
    response = requests.get(f'{BASE_URL}wall.get', params=params, headers=HEADERS)
    if response.status_code == 200:
        body = response.json()
        body = body['response']

        count_posts = body.get('count')
        group_info['count_posts'] = count_posts
    else:
        count_posts = None

    if count_posts:
        total_batches = int(int(count_posts) / 100) + 1
        count = 100
        params['count'] = count

        threads = [None] * total_batches
        results = [None] * total_batches

        for i in range(0, total_batches):

            threads[i] = Thread(target=open_url, args=(params, f'{BASE_URL}wall.get', results, i, i * count))

        thread_processing(threads, total_batches, 10)

        comment, likes, views, reposts = 0, 0, 0, 0
        has_mat = False
        ban_words = get_ban_words()
        for response in results:
            try:
                if response.status_code == 200:
                    body = response.json()

                    if 'response' in body:
                        for item in body['response']['items']:
                            likes += item['likes']['count']
                            comment += item['comments']['count']

                            if 'views' in item:
                                views += item['views']['count']

                            reposts += item['reposts']['count']

                            if not has_mat:
                                text = item['text']
                                text = [word.strip(string.punctuation) for word in text.split()]
                                has_mat = find_ban_words(text, ban_words)
            except:
                pass

        group_info['count_likes'] = likes
        group_info['count_comment'] = comment
        group_info['count_views'] = views
        group_info['count_reposts'] = reposts
        group_info['has_mat'] = has_mat

    return group_info


@backoff.on_exception(backoff.expo, KeyError, max_tries=5)
def open_url(params, url, result, index, offset):
    params['offset'] = offset
    response = requests.get(url, params=params, headers=HEADERS)
    body = response.json()
    body = body['response']
    result[index] = response


def thread_processing(threads, total_batches, amount_threads):
    for i in range(0, total_batches):
        threads[i].start()
        if i % amount_threads == 0 and i != 0:
            for j in range(0, amount_threads):
                threads[i - j].join()
        elif i == 0:
            threads[i].join()

        elif i == total_batches - 1:
            n = i % amount_threads
            for j in range(0, n):
                threads[i - j].join()


def find_ban_words(text, ban_words):
    # pattern = r"(\s+|^)[пПnрРp]?[3ЗзВBвПnпрРpPАaAаОoO0о]?[сСcCиИuUОoO0оАaAаыЫуУyтТT]?[Ппn][иИuUeEеЕ][зЗ3][ДдDd]\w*[\?\,\.\;\-]*|(\s+|^)[рРpPпПn]?[рРpPоОoO0аАaAзЗ3]?[оОoO0иИuUаАaAcCсСзЗ3тТTуУy]?[XxХх][уУy][йЙеЕeEeяЯ9юЮ]\w*[\?\,\.\;\-]*|(\s+|^)[бпПnБ6][лЛ][яЯ9]([дтДТDT]\w*)?[\?\,\.\;\-]*|(\s+|^)(([зЗоОoO03]?[аАaAтТT]?[ъЪ]?)|(\w+[оОOo0еЕeE]))?[еЕeEиИuUёЁ][бБ6пП]([аАaAиИuUуУy]\w*)?[\?\,\.\;\-]*"
    for x in text:
        # x = Mystem().lemmatize(x)
        if x in ban_words: # or re.search(pattern, x):
            return True
    return False


def get_ban_words():
    file1 = open("analytics/services/ban_words.txt", "r")

    lines = file1.readlines()
    ban_words = []

    for line in lines:
        ban_words.append(line.split('\n')[0])

    file1.close()

    return ban_words
