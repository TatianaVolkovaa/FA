from analytics.models import Group
from analytics.services.graph import create_graphs
from analytics.services.metrics import get_er, get_lr, get_tr
from analytics.services.vk import get_common_info, get_wall_info, get_members_info
from config.celery import app


@app.task(serializer='json')
def update_group(pk):

    group = Group.objects.filter(id=pk).first()
    group_name = group.link.split('vk.com/')[1]
    data = get_common_info(group_name)
    data = get_wall_info(group_name, data)
    data = get_members_info(group_name, data)
    data = count_average(data)

    data['er'] = get_er(
        data['count_members'],
        data['average_likes'],
        data['average_comment'],
        data['average_reposts']
    )

    data['lr'] = get_lr(
        data['average_likes'],
        data['count_members']
    )

    data['tr'] = get_tr(
        data['average_comment'],
        data['count_members'],
    )

    graph_pats = create_graphs(group_name, data['members_info'])
    data.update(graph_pats)
    data['status'] = Group.Status.ready
    Group.objects.filter(id=pk).update(**data)


def count_average(data):
    data['average_likes'] = data['count_likes'] / data['count_posts']
    data['average_comment'] = data['count_comment'] / data['count_posts']
    data['average_reposts'] = data['count_reposts'] / data['count_posts']
    data['average_views'] = data['count_views'] / data['count_posts']

    return data



