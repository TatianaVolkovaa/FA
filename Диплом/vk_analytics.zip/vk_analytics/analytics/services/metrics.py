def get_er(count_members, average_likes, average_comment, average_reposts):
    try:
        return round((average_likes + average_comment + average_reposts) / count_members * 100, 2)

    except:
        return None


def get_lr(average_likes, count_members):
    try:
        return round(average_likes / count_members * 100, 2)

    except:
        return None


def get_tr(average_comment, count_members):
    try:
        return round(average_comment / count_members * 100, 2)
    except:
        return None
