from collections import Counter

import matplotlib.pyplot as plt
import numpy as np
from translate import Translator

from config.settings import MEDIA_ROOT


def create_graphs(group_name, data):
    labels = ['Мужской', 'Женский']
    values = [data['male'], data['female']]

    sex_path = f'sex/{group_name}.png'
    create_pie(labels, values, sex_path, 'По полу')

    labels, values = normalaize_value(data, 3, 'country')
    country_path = f'country/{group_name}.png'
    create_pie(labels, values, country_path, 'По странам')

    labels, values = normalaize_value(data, 7, 'city')
    city_path = f'city/{group_name}.png'
    create_pie(labels, values, city_path, 'По городам')

    age = data['age']
    labels = list(age.keys())
    values = list(age.values())

    age_path = f'age/{group_name}.png'
    create_bar(labels, values, age_path)

    return {'sex': sex_path, 'city': city_path, 'country': country_path, 'age': age_path}


def normalaize_value(data, level, key):
    translator = Translator(from_lang="english", to_lang="russian")

    input_data = data[key]

    most_popular = Counter(input_data)
    most_popular = most_popular.most_common()

    output_data = {}
    i = 0
    for k, v in most_popular:
        if i < level:
            try:
                k = translator.translate(k)
            except:
                pass
            output_data.update({k: v})
        else:
            if 'Другие' in output_data:
                output_data['Другие'] += v
            else:
                output_data['Другие'] = v
        i += 1

    labels = list(output_data.keys())
    values = list(output_data.values())
    return labels, values


def create_pie(labels, values, path, title):
    fig1, ax1 = plt.subplots()
    ax1.pie(values)
    ax1.set_title(title)
    ax1.axis('equal')
    percent_values = calculate_percent(values)
    labels = [f'{l}, {s:0.1f}%' for l, s in zip(labels, percent_values)]
    ax1.legend(loc='best', labels=labels)
    plt.savefig(f'{MEDIA_ROOT}/{path}')


def create_bar(labels, values, path):
    values = np.array(values)

    fig1, ax1 = plt.subplots()
    ax1.set_title('По возрасту')
    ax1.bar(labels, values)
    ax1.legend(loc='best')
    plt.savefig(f'{MEDIA_ROOT}/{path}')


def calculate_percent(values):
    percent_values = []
    s = sum(values)
    for v in values:
        percent_values.append(v * 100.0 / s)
    return percent_values
