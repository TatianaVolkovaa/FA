from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic import DeleteView, View

from analytics.forms import GroupModelForm
from analytics.models import Group
from analytics.services.groups import update_group
from user.views import IsUserAuthenticatedMixin
from analytics.services.vk import get_common_info


class GroupListView(IsUserAuthenticatedMixin, View):
    """ Список групп """
    @staticmethod
    def get(request):
        # sort = request.GET.get('name', None)
        # if sort == 'asc':
        #     group_list = Group.objects.filter(user=request.user).order_by('-name').all()
        #     sort_by_name = 'desc'
        # elif sort == 'desc':
        #     group_list = Group.objects.filter(user=request.user).order_by('name').all()
        #     sort_by_name = None
        # else:
        #     group_list = Group.objects.filter(user=request.user).all()
        #     sort_by_name = 'asc'
        #
        # return render(request, 'analytics/list.html', {
        #     'group_list': group_list,
        #     'sort_by_name': sort_by_name
        # })
        group_list = Group.objects.filter(user=request.user)

        sort_by_name = request.GET.get('sort_by_name')
        sort_by_er = request.GET.get('sort_by_er')
        sort_by_tr = request.GET.get('sort_by_tr')
        sort_by_lr = request.GET.get('sort_by_lr')
        sort_by_followers = request.GET.get('sort_by_followers')

        if sort_by_name == 'asc':
            group_list = group_list.order_by('name').all()
            sort_by_name = 'desc'
        elif sort_by_name == 'desc':
            group_list = group_list.order_by('-name').all()
            sort_by_name = 'asc'
        else:
            sort_by_name = 'asc'

        if sort_by_er == 'asc':
            group_list = group_list.order_by('er').all()
            sort_by_er = 'desc'
        elif sort_by_er == 'desc':
            group_list = group_list.order_by('-er').all()
            sort_by_er = 'asc'
        else:
            sort_by_er = 'asc'

        if sort_by_tr == 'asc':
            group_list = group_list.order_by('tr').all()
            sort_by_tr = 'desc'
        elif sort_by_tr == 'desc':
            group_list = group_list.order_by('-tr').all()
            sort_by_tr = 'asc'
        else:
            sort_by_tr = 'asc'

        if sort_by_lr == 'asc':
            group_list = group_list.order_by('lr').all()
            sort_by_lr = 'desc'
        elif sort_by_lr == 'desc':
            group_list = group_list.order_by('-lr').all()
            sort_by_lr = 'asc'
        else:
            sort_by_lr = 'asc'

        if sort_by_followers == 'asc':
            group_list = group_list.order_by('count_members').all()
            sort_by_followers = 'desc'
        elif sort_by_followers == 'desc':
            group_list = group_list.order_by('-count_members').all()
            sort_by_followers = 'asc'
        else:
            sort_by_followers = 'asc'

        return render(request, 'analytics/list.html', {
            'group_list': group_list,
            'sort_by_name': sort_by_name,
            'sort_by_er': sort_by_er,
            'sort_by_tr': sort_by_tr,
            'sort_by_lr': sort_by_lr,
            'sort_by_followers': sort_by_followers,
        })

    @staticmethod
    def post(request):
        search = request.POST.get('search')
        return render(request, 'analytics/list.html', {
            'group_list': Group.objects.filter(user=request.user, name__icontains=search).all(),
            'sort_by_name': 'asc'
        })


class GroupDetailView(IsUserAuthenticatedMixin, View):
    """Информация по конкретной группе"""
    @staticmethod
    def get(request, pk):
        group = Group.objects.filter(id=pk).first()
        return render(request, 'analytics/detail.html', {
            'group': group
        })


class GroupCreateView(IsUserAuthenticatedMixin, View):
    """Добавление группы"""
    @staticmethod
    def get(request):
        return render(request, 'analytics/create.html', {'form': GroupModelForm})

    @staticmethod
    def post(request):
        form = GroupModelForm(request.POST)
        link = form.data['link']
        if Group.objects.filter(user=request.user, link=link).first():
            return render(request, 'analytics/create.html', {
                'form': GroupModelForm,
                'error': 'У вас уже добавлена эта группа'
            })

        try:
            group_name = link.split('vk.com/')[1]
            info = get_common_info(group_name)
            if not info:
                return render(request, 'analytics/create.html', {
                    'form': GroupModelForm,
                    'error': 'Данная группа не найдена'
                })

            info.update({'user': request.user, 'link': link, 'status': Group.Status.in_progress})
            group = Group.objects.create(**info)
            update_group.delay(group.id)
        except:
            return render(request, 'analytics/create.html', {
                'form': GroupModelForm,
                'error': 'Неправильно введена ссылка'
            })
        return redirect('analytics:index')


class GroupUpdateView(IsUserAuthenticatedMixin, View):
    """Обновление информации"""
    @staticmethod
    def get(request, pk):
        Group.objects.filter(id=pk).update(status=Group.Status.in_progress)
        update_group.delay(pk)
        return redirect('analytics:index')


class GroupDeleteView(DeleteView):
    """Удаление группы"""
    model = Group
    template_name = "analytics/delete.html"
    success_url = reverse_lazy("analytics:index")


class AboutPageView(IsUserAuthenticatedMixin, View):
    """Страница с информацией о проекте"""
    @staticmethod
    def get(request):
        return render(request, 'analytics/about.html')
