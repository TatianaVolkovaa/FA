from django.urls import path

from analytics.views import (GroupCreateView, GroupDeleteView, GroupDetailView,
                             GroupListView, GroupUpdateView, AboutPageView)

app_name = 'analytics'

urlpatterns = [
    path('', GroupListView.as_view(), name='index'),
    path('create', GroupCreateView.as_view(), name='create'),
    path('<int:pk>', GroupDetailView.as_view(), name='detail'),
    path('update/<int:pk>', GroupUpdateView.as_view(), name='update'),
    path('delete/<int:pk>', GroupDeleteView.as_view(), name='delete'),
    path('about-us', AboutPageView.as_view(), name='about'),
]
