from django.db import models
from django.utils.translation import gettext_lazy as _
from user.models import User


class Group(models.Model):
    """ Группа """

    class Status(models.TextChoices):
        in_progress = 'in progress', _('В обработке')
        ready = 'ready', _('Готово')

    link = models.CharField(max_length=255, verbose_name='Ссылка на группу')
    name = models.CharField(max_length=255, verbose_name='Название', blank=True, null=True)
    count_members = models.IntegerField(verbose_name='Кол-во подписчиков', blank=True, null=True)
    count_likes = models.IntegerField(verbose_name='Кол-во лайков', blank=True, null=True)
    count_comment = models.IntegerField(verbose_name='Кол-во комментариев', blank=True, null=True)
    count_views = models.IntegerField(verbose_name='Кол-во просмотров', blank=True, null=True)
    count_reposts = models.IntegerField(verbose_name='Кол-во репостов', blank=True, null=True)
    count_posts = models.IntegerField(verbose_name='Кол-во постов', blank=True, null=True)

    average_likes = models.IntegerField(verbose_name='Среднее кол-во лайков', blank=True, null=True)
    average_comment = models.IntegerField(verbose_name='Среднее кол-во комментариев', blank=True, null=True)
    average_reposts = models.IntegerField(verbose_name='Среднее кол-во репостов', blank=True, null=True)
    average_views = models.IntegerField(verbose_name='Среднее кол-во просмотров', blank=True, null=True)

    has_mat = models.BooleanField(verbose_name='Нелегетимные посты', blank=True, null=True)

    members_info = models.JSONField(verbose_name='Информация об участниках', blank=True, null=True)

    er = models.FloatField(verbose_name='ER', blank=True, null=True)
    lr = models.FloatField(verbose_name='LR', blank=True, null=True)
    tr = models.FloatField(verbose_name='TR', blank=True, null=True)

    age = models.ImageField(blank=True, upload_to='age')
    city = models.ImageField(blank=True, upload_to='city')
    country = models.ImageField(blank=True, upload_to='country')
    sex = models.ImageField(blank=True, upload_to='sex')

    status = models.CharField(
        _('Статус'),
        max_length=100,
        choices=Status.choices,
        default=Status.in_progress
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    user = models.ForeignKey(User, on_delete=models.CASCADE)
