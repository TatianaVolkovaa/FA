from django import forms

from .models import Group


class GroupModelForm(forms.ModelForm):
    """Задача-группа"""

    class Meta:
        model = Group
        fields = ['link']
