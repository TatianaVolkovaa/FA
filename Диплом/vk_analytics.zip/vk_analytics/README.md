# vk_analytics
Аналитика сообществ vk.com через API.

Подготовка
1. `docker compose up -d`  (у вас должен быть докер или редис)
2. создаем виртуальную оболочку и запускаем ее `.\venv\scripts\activate` (если не получается, от имени администратора: Set-ExecutionPolicy Unrestricted)
3. `pip install -r requirements.txt` - скачиваем все необходимые пакеты и библиотеки
4. `python manage.py migrate` - проводим все необходимые миграции
5. `python manage.py createsuperuser` - создаем суперюзера (админа)


Запуск: 

`docker compose up -d`- поднимаем контейнер

`celery -A config worker --pool solo -l INFO` - запуск Celery в 1 терминале

`python manage.py runserver` - старт DJANGO во 2 терминале